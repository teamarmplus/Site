# SiteVerdict Pull Request

## Package number
<!-- Must match version.json and build_name -->
Package: <!-- e.g. 82 -->

## What changed
<!-- One-line summary -->

## Why this changed
<!-- Root cause or source of change -->

## Release check result
<!-- Paste the output of npm run release-check here -->
<!-- Do NOT merge without a passing release-check -->

```
[paste release-check output here]
```

## Browser test result
<!-- All Playwright tests must pass -->
- [ ] 14/14 browser tests passed
- [ ] NSW comma and no-comma both render report cards
- [ ] Fake address rejects cleanly
- [ ] QLD/VIC/TAS/ACT/SA/WA/NT all render without NSW overlay text
- [ ] Button re-enabled after every check
- [ ] version.json shows correct package number

## Static check result
- [ ] `npm run predeploy` passed (76/76 or higher)
- [ ] No NSW-only wording in user-facing HTML
- [ ] No raw spatial datasets in public/
- [ ] No literal API keys in any file

## Site Check behaviour confirmed
- [ ] Never hangs on "Checking..."
- [ ] SITE_CHECK_TIMEOUT card fires if result takes > 20s
- [ ] NSW deep check intact (mapprod3 URL present)
- [ ] Non-NSW state gate active (_detState check present)

## Deploy URLs to verify after merge
- `/version.json` → package_number matches this PR
- `/deploy-check.html` → SAFE TO CONTINUE
- `/.netlify/functions/sitecheck-test` → allPassed: true

## Founder approval needed?
- [ ] No — pure automated fix, AI can merge
- [ ] Yes — direction/ethics/data/partnership decision required

<!-- If "Yes", tag @tung and describe the decision needed -->
